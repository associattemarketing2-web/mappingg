<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="X-UA-Compatible" content="ie=edge"><title>Maharashtra Real Estate Regulatory Authority</title><script src="https://cdn.jsdelivr.net/npm/regenerator-runtime@0.13.7/runtime.min.js"></script><link href="https://maharerait.maharashtra.gov.in/content/assets/css/style.css" rel="stylesheet"/><link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet"/><link href="https://maharerait.maharashtra.gov.in/content/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"/><link href="https://maharerait.maharashtra.gov.in/content/assets/vendor/simple-datatables/style.css" rel="stylesheet"/><link href="https://maharerait.maharashtra.gov.in/content/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet"/><link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet"><link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet"><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans"/><link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"/><script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><script async defer="defer" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBODKQJRZF8Es5yjpj0uhADgssqUlRkBd8"></script><link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css"><script src="https://code.jquery.com/jquery-3.6.0.js"></script><script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script><script src="https://cdn.jsdelivr.net/npm/regenerator-runtime@0.13.7/runtime.min.js"></script><link href="https://unpkg.com/angular-calendar@0.26.6/css/angular-calendar.css" rel="stylesheet"><link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"><script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script><script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.2.12/pdfobject.min.js"></script><script type="systemjs-importmap">{
      "imports": {
        "single-spa": "https://cdn.jsdelivr.net/npm/single-spa@5.9.0/lib/system/single-spa.min.js",
        "login":"//maharerait.maharashtra.gov.in/loginpage/main.js",
        "register":"//maharerait.maharashtra.gov.in/registerpage/main.js",
        "admin":"//maharerait.maharashtra.gov.in/adminpage/main.js",
        "dashboard":"//maharerait.maharashtra.gov.in/dashboardpage/main.js",
        "promoter":"//maharerait.maharashtra.gov.in/promoterpage/main.js",
        "workflow":"//maharerait.maharashtra.gov.in/workflowpage/main.js",
        "header":"//maharerait.maharashtra.gov.in/headerpage/main.js",
        "agent":"//maharerait.maharashtra.gov.in/agentpage/main.js",
        "project":"//maharerait.maharashtra.gov.in/projectpage/main.js",
        "inbox":"//maharerait.maharashtra.gov.in/inboxpage/main.js",
        "complaint":"//maharerait.maharashtra.gov.in/complaintpage/main.js",
        "appeal":"//maharerait.maharashtra.gov.in/appealpage/main.js",
        "appeal-login":"//maharerait.maharashtra.gov.in/appealloginpage/main.js",
        "public":"//maharerait.maharashtra.gov.in/publicpage/main.js"


      }
    }</script><link rel="preload" href="https://cdn.jsdelivr.net/npm/single-spa@5.9.0/lib/system/single-spa.min.js" as="script" crossorigin="anonymous"><script type="systemjs-importmap">{
          "imports": {
            "@single-spa/welcome": "https://unpkg.com/single-spa-welcome/dist/single-spa-welcome.js",
            "@maha-rera/root-config": "https://maharerait.maharashtra.gov.in/maha-rera-root-config.js",
            "@maha-rera/login":"https://maharerait.maharashtra.gov.in/loginpage/main.js",
            "@maha-rera/register":"https://maharerait.maharashtra.gov.in/registerpage/main.js",
            "@maha-rera/admin":"https://maharerait.maharashtra.gov.in/adminpage/main.js",
            "@maha-rera/dashboard":"https://maharerait.maharashtra.gov.in/dashboardpage/main.js",
            "@maha-rera/promoter":"https://maharerait.maharashtra.gov.in/promoterpage/main.js",
            "@maha-rera/workflow":"https://maharerait.maharashtra.gov.in/workflowpage/main.js",
            "@maha-rera/header":"https://maharerait.maharashtra.gov.in/headerpage/main.js",
            "@maha-rera/agent":"https://maharerait.maharashtra.gov.in/agentpage/main.js",
            "@maha-rera/project":"https://maharerait.maharashtra.gov.in/projectpage/main.js",
            "@maha-rera/inbox":"https://maharerait.maharashtra.gov.in/inboxpage/main.js",
            "@maha-rera/complaint":"https://maharerait.maharashtra.gov.in/complaintpage/main.js",
            "@maha-rera/appeal":"https://maharerait.maharashtra.gov.in/appealpage/main.js",
            "@maha-rera/appeal-login":"https://maharerait.maharashtra.gov.in/appealloginpage/main.js",
            "@maha-rera/public":"https://maharerait.maharashtra.gov.in/publicpage/main.js"

          }
        }</script><script src="https://cdn.jsdelivr.net/npm/zone.js@0.11.3/dist/zone.min.js"></script><script src="https://cdn.jsdelivr.net/npm/import-map-overrides@2.2.0/dist/import-map-overrides.js"></script><script src="https://cdn.jsdelivr.net/npm/systemjs@6.8.3/dist/system.min.js"></script><script src="https://cdn.jsdelivr.net/npm/systemjs@6.8.3/dist/extras/amd.min.js"></script></head><body><noscript>You need to enable JavaScript to run this app.</noscript><script>System.import('@maha-rera/root-config');</script><import-map-overrides-full show-when-local-storage="devtools" dev-libs></import-map-overrides-full><script>/* 
window.apmrum = (window.apmrum || {});
window.apmrum.serviceName='main-app-uat';
window.apmrum.webApplication='main-app-uat';
window.apmrum.ociDataUploadEndpoint='https://aaaadc7v4pjuqaaaaaaaaabs7e.apm-agt.ap-mumbai-1.oci.oraclecloud.com';
window.apmrum.OracleAPMPublicDataKey='A6O63NFNBOAPIWSQWDLT3RC3WZVE25LN';
*/</script><script>(function () {
        "use strict";

        /**
         * Easy selector helper function
         */
        const select = (el, all = false) => {
            el = el.trim();
            if (all) {
                return [...document.querySelectorAll(el)];
            } else {
                return document.querySelector(el);
            }
        };

        /**
         * Easy event listener function
         */
        const on = (type, el, listener, all = false) => {
            if (all) {
                select(el, all).forEach((e) => e.addEventListener(type, listener));
            } else {
                select(el, all).addEventListener(type, listener);
            }
        };

        /**
         * Easy on scroll event listener
         */
        const onscroll = (el, listener) => {
            el.addEventListener("scroll", listener);
        };

        /**
         * Sidebar toggle
         */
        if (select(".toggle-sidebar-btn")) {
            on("click", ".toggle-sidebar-btn", function (e) {
                select("body").classList.toggle("toggle-sidebar");
            });
        }

        /**
         * Search bar toggle
         */
        if (select(".search-bar-toggle")) {
            on("click", ".search-bar-toggle", function (e) {
                select(".search-bar").classList.toggle("search-bar-show");
            });
        }

        /**
         * Navbar links active state on scroll
         */
        let navbarlinks = select("#navbar .scrollto", true);
        const navbarlinksActive = () => {
            let position = window.scrollY + 200;
            navbarlinks.forEach((navbarlink) => {
                if (!navbarlink.hash) return;
                let section = select(navbarlink.hash);
                if (!section) return;
                if (position >= section.offsetTop && position <= section.offsetTop + section.offsetHeight) {
                    navbarlink.classList.add("active");
                } else {
                    navbarlink.classList.remove("active");
                }
            });
        };
        window.addEventListener("load", navbarlinksActive);
        onscroll(document, navbarlinksActive);

        /**
         * Toggle .header-scrolled class to #header when page is scrolled
         */
        let selectHeader = select("#header");
        if (selectHeader) {
            const headerScrolled = () => {
                if (window.scrollY > 100) {
                    selectHeader.classList.add("header-scrolled");
                } else {
                    selectHeader.classList.remove("header-scrolled");
                }
            };
            window.addEventListener("load", headerScrolled);
            onscroll(document, headerScrolled);
        }

        /**
         * Initiate Datatables
         */
        const datatables = select(".datatable", true);
        datatables.forEach((datatable) => {
            new simpleDatatables.DataTable(datatable);
        });
    })();

   function scrollTabs(param) {
     
                let hidWidth;
                let scrollBarWidths = 40;

                let widthOfList = function () {
                    let itemsWidth = 0;
                    $(`#${param} li`).each(function () {
                        let itemWidth = $(this).outerWidth();
                        itemsWidth += itemWidth;
                    });
                    return itemsWidth;
                };

                var widthOfHidden = function () {
                    return $(`#${param}-wrapper ` + ".wrapper").outerWidth() - widthOfList() - getLeftPosi() - scrollBarWidths;
                };

                let getLeftPosi = function () {
                    return $(`#${param}`).position().left;
                };

                var reAdjust = function () {
                    if ($(`#${param}-wrapper ` + ".wrapper").outerWidth() < widthOfList()) {
                        $(`#${param}-wrapper ` + ".scroller-right").show();
                    } else {
                        $(`#${param}-wrapper ` + ".scroller-right").hide();
                    }

                    if (getLeftPosi() < 0) {
                        $(`#${param}-wrapper ` + ".scroller-left").show();
                    } else {
                        $(`#${param}-wrapper ` + ".item").animate({ left: "-=" + getLeftPosi() + "px" }, "slow");
                        $(`#${param}-wrapper ` + ".scroller-left").hide();
                    }
                };

                reAdjust();

                $(window).on("resize", function (e) {
                    reAdjust();
                });
                let ScrollPosArray = [];
                rDisabled=false;
                $(`#${param}-wrapper ` + ".scroller-right").click(function () {
                    if(rDisabled)
                    {
                        return;
                    }
                    rDisabled=true;
                    $(`#${param}-wrapper ` + ".scroller-right").fadeIn("slow");
                   
                    var getAlreadyScrolledWidth = function () {
                    if(ScrollPosArray && ScrollPosArray.length>0)
                    {
                    var itemsWidthHidden=0;
                        ScrollPosArray.map(item=> {
                            itemsWidthHidden += item;
                    });
                    }
                    return itemsWidthHidden;
                };
                    //let widthOfHidden1 = -widthOfHidden() < $(".wrapper").outerWidth() ? widthOfHidden() : -$(".wrapper").outerWidth();
                   // widthOfHidden1=-(widthOfList()-(-widthOfHidden())>$(`#${param}-wrapper ` + ".wrapper").outerWidth()?$(`#${param}-wrapper ` + ".wrapper").outerWidth():-widthOfHidden());
                    widthOfHidden1=-155;
                    ScrollPosArray.push(widthOfHidden1);
                    console.log(ScrollPosArray);
                    $(`#${param}`).animate({ left: "+=" + widthOfHidden1 + "px" }, "slow", function () {
                        // console.log(widthOfHidden())
                        if (-widthOfHidden()/2 < 1) {
                            $(`#${param}-wrapper ` + ".scroller-right").fadeOut("slow");
                        }
                        else
                        {
                            $(`#${param}-wrapper ` + ".scroller-left").fadeIn("slow");
                        }
                    });                    
                   setTimeout(() => {
                    rDisabled=false;
                   }, 1000);
                });
                 lDisabled=false;
                $(`#${param}-wrapper ` + ".scroller-left").click(function () {
                    if (ScrollPosArray.length !== 0) {
                       if(lDisabled)
                       {
                        return;
                       }
                       lDisabled=true;
                        $(`#${param}`).animate({ left: "-=" + ScrollPosArray[ScrollPosArray.length - 1] + "px" }, "slow", function () {
                            ScrollPosArray.pop();
                            if (ScrollPosArray.length == 0) {
                                $(`#${param}-wrapper ` + ".scroller-left").fadeOut("slow");
                            }
                            else
                            {
                                $(`#${param}-wrapper ` + ".scroller-right").fadeIn("slow");
                            }
                        });
                        setTimeout(() => {
                            lDisabled=false;
                        }, 1000);
                    }
                    console.log(ScrollPosArray);
                });
            }





function initializeDatatable(id)
{
   if($.fn.dataTable.isDataTable("#"+id))
   {
    $("#"+id).DataTable().destroy();
   }
    if($("#"+id+">thead>tr:first>th:first").hasClass('sorting'))
    {

        $("#"+id).DataTable().destroy();
               
        setTimeout(() => {
            new DataTable('#'+id,{
        autoWidth:false,
        lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, 'All']
    ]
    // ,
    // order: [[0, 'desc']]
    });
        }, 500);
        // // $("#"+id).DataTable().destroy();
        // // $("#"+id).DataTable().draw();
        // $("#"+id+">thead>tr:first>th:first").click()
        // $("#"+id+">thead>tr:first>th:first").click()  
        return;
    }
    new DataTable('#'+id,{
        autoWidth:false,
        lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, 'All']
    ]
    // ,
    // order: [[0, 'desc']]
    });
}

function deinitializeDatatable(id)
{
    if($.fn.dataTable.isDataTable("#"+id))
   {
    $("#"+id).DataTable().destroy();
   }
    if($("#"+id+">thead>tr:first>th:first").hasClass('sorting'))
    {

        $("#"+id).DataTable().destroy();
        // // $("#"+id).DataTable().destroy();
        // // $("#"+id).DataTable().draw();
        // $("#"+id+">thead>tr:first>th:first").click()
        // $("#"+id+">thead>tr:first>th:first").click()  
        return;
    }
}

function initializedTooltip()
{
    $('[data-toggle="tooltip"]').tooltip();
}

function showPDF(pdfname,divname)
{
    PDFObject.embed(pdfname, "#"+divname);
}</script></body></html>